package net.osgg.xmlserving;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XmlservingApplicationTests {

	@Test
	void contextLoads() {
	}

}
