INSERT INTO employees (first_name, last_name, email_address) VALUES ('Ana', 'Lopez', 'a@g.com');
INSERT INTO employees (first_name, last_name, email_address) VALUES ('Alberto', 'Cruz', 'a@c.com');
INSERT INTO employees (first_name, last_name, email_address) VALUES ('Julia', 'Paz', 'j@p.com');